import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation1-menu',
  templateUrl: './navigation1-menu.component.html',
  styleUrls: ['./navigation1-menu.component.css']
})
export class Navigation1MenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
