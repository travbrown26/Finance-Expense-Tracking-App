import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Navigation1MenuComponent } from './navigation1-menu.component';

describe('Navigation1MenuComponent', () => {
  let component: Navigation1MenuComponent;
  let fixture: ComponentFixture<Navigation1MenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Navigation1MenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Navigation1MenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
