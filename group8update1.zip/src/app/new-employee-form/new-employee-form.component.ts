import { Component, OnInit, Input } from '@angular/core';
import { EmployeeService } from '../employee.service';  
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';


@Component({
  selector: 'app-new-employee-form',
  templateUrl: './new-employee-form.component.html',
  styleUrls: ['./new-employee-form.component.css']
})
export class NewEmployeeFormComponent implements OnInit {

  @Input() firstName: string;
  @Input() lastName: string;
  @Input() email: string;
  @Input() address: string;
  @Input() cityName: string;
  @Input() stateName: string;
  @Input() zipCode: string;
  @Input() positionName: string;
  @Input() salaryAmount: number;
  private mode = 'Add'; //default mode
  private id: string; //Employee ID
private oneEmployee;


  constructor(private _myService: EmployeeService, private router:Router, public route: ActivatedRoute) { }
  
  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
        { this.mode = 'Edit'; /*request had a parameter _id */ 
          this.id = paramMap.get('_id');
          this.getOneEmployee(this.id);
        }
      else {this.mode = 'Add';
          this.id = null; }
    });
    
 }
 getOneEmployee(id: string) {
  this._myService.getOneEmployee(id).subscribe(
    //read data and assign to public variable students
    data => { this.oneEmployee = data },
    err => console.error(err),
    () => {
      console.log(this.oneEmployee._id);
      this.firstName = this.oneEmployee.firstName;
      this.lastName = this.oneEmployee.lastName;
      this.email = this.oneEmployee.email;
      this.address = this.oneEmployee.address;
      this.cityName = this.oneEmployee.cityName;
      this.stateName = this.oneEmployee.stateName;
      this.zipCode = this.oneEmployee.zipCode;
      this.positionName = this.oneEmployee.positionName;
      this.salaryAmount = this.oneEmployee.salaryAmount
    }

  );

}
onSubmit(){
  console.log("You submitted: " + this.firstName + "" + this.lastName + "" + this.email + "" + this.address + "" + this.cityName + "" + this.stateName + "" + this.zipCode + "" + this.positionName + "" + this.salaryAmount);
  
  if(this.mode == 'Add')
    this._myService.addEmployees(this.firstName ,this.lastName,this.email,this.address, this.cityName,this.stateName,this.zipCode,this.positionName,this.salaryAmount);
  if(this.mode == 'Edit')
    this._myService.updateEmployee(this.id,this.firstName ,this.lastName, this.email,this.address, this.cityName,this.stateName,this.zipCode,this.positionName,this.salaryAmount);
    location.reload();
}



    
  
  }
  

