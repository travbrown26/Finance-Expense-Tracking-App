import { Component, OnInit } from '@angular/core';
import { ExpenseSrvc } from '../expenses.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-filtered-expenses',
  templateUrl: './filtered-expenses.component.html',
  styleUrls: ['./filtered-expenses.component.css']
})
export class FilteredExpensesComponent implements OnInit {

  public monthlyexpenses;
  public yearPrm;
  public amtPrm;
  public yrOpPrm;
  public amtOpPrm;
  public categoryPrm;
  public monthPrm;

  constructor(private _myService: ExpenseSrvc, private router: Router) {

    if (this.router.getCurrentNavigation().initialUrl != '/search') {
      this.router.navigate(['/search']);
    }
    this.yearPrm = this.router.getCurrentNavigation().extras.state.year;
    this.amtPrm = this.router.getCurrentNavigation().extras.state.amount;
    this.yrOpPrm = this.router.getCurrentNavigation().extras.state.yearOp;
    this.amtOpPrm = this.router.getCurrentNavigation().extras.state.amtOp;
    this.categoryPrm = this.router.getCurrentNavigation().extras.state.category;
    this.monthPrm = this.router.getCurrentNavigation().extras.state.month;
    
  }

  ngOnInit() {
    // this.getExpenseList();
    this.getFilteredExpenseList();
  }

  onDelete(expenseId: string) {
    this._myService.deleteExpense(expenseId);
  }

  getFilteredExpenseList() {
    this._myService.getByFilter(this.monthPrm, this.yearPrm, this.yrOpPrm, this.amtPrm, this.amtOpPrm, this.categoryPrm).subscribe(
      //read data and assign to public variable students
      data => { this.monthlyexpenses = data },
      err => console.error(err),
      () => console.log('finished filtered loading expenses')
    );
  }

  getMnth(mn: number) {
    var d = ' ';
    if (mn == 1) { d = 'Jan'; }
    if (mn == 2) { d = 'Feb'; }
    if (mn == 3) { d = 'Mar'; }
    if (mn == 4) { d = 'Apr'; }
    if (mn == 5) { d = 'May'; }
    if (mn == 6) { d = 'Jun'; }
    if (mn == 7) { d = 'Jul'; }
    if (mn == 8) { d = 'Aug'; }
    if (mn == 9) { d = 'Sep'; }
    if (mn == 10) { d = 'Oct'; }
    if (mn == 11) { d = 'Nov'; }
    if (mn == 12) { d = 'Dec'; }
    return d;
  }



}