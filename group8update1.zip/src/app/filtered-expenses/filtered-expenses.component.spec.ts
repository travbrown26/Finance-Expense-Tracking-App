import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilteredExpensesComponent } from './filtered-expenses.component';

describe('FilteredExpensesComponent', () => {
  let component: FilteredExpensesComponent;
  let fixture: ComponentFixture<FilteredExpensesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilteredExpensesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilteredExpensesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
