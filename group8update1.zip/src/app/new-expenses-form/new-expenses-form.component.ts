import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute, ParamMap } from '@angular/router';
import { ExpenseSrvc } from '../expenses.service';
import { EmployeeService } from '../employee.service';

export interface Calendar {
  value: number;
  viewValue: string;
}

@Component({
  selector: 'app-new-expenses-form',
  templateUrl: './new-expenses-form.component.html',
  styleUrls: ['./new-expenses-form.component.css'],
  providers: []
})

export class NewExpenseFormComponent implements OnInit {
  @Input() empId: string;
  @Input() month: number;
  @Input() year: number;
  @Input() amount: number;
  @Input() description: string;
  @Input() category: string;
  @Input() notes: string;

  constructor(private _myService: ExpenseSrvc, private _myService2: EmployeeService, private router: Router, public route: ActivatedRoute) { }

  private mode = 'add'; //default mode
  private id: string; //student ID
  public formTitle = 'Add New Expense'; //default mode
  public buttonLbl = 'Submit';
  private def_val = '';

  private oneExpense;
  private empList;

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) => {
      if (paramMap.has('_id')) {
        this.mode = 'edit'; /*request had a parameter _id */
        this.id = paramMap.get('_id');
        this.formTitle = 'Edit Existing Expense';
        this.buttonLbl = 'Update';
        this.getOneExpense(this.id);

      }
      else {
        this.mode = 'add';
        this.id = null;
        this.formTitle = 'Add New Expense';
        //this.getEmployeeList();
        console.log("New Mode");
        
      }
      this.getEmployeeList();
    });

  }



  onSubmit() {
    console.log("You submitted: " + this.empId + " " + + this.month + " " + this.amount + " " + this.description + " " + this.category + " " + this.notes);
    this.notes = (typeof this.notes === 'undefined') ? this.def_val : this.notes;
    
      if (this.mode == 'add')
      this._myService.addExpenses(this.empId, this.month, this.year, this.amount, this.description, this.category, this.notes);
    if (this.mode == 'edit')
      this._myService.updateExpenses(this.id, this.empId, this.month, this.year, this.amount, this.description, this.category, this.notes);



    this.router.navigate(['/'], { skipLocationChange: true }).then(
      () => {
        console.log('Fwding from url');
        this.router.navigate(['/listExpenses']);
      });

  }

  getOneExpense(id: string) {
    this._myService.getOneExpense(id).subscribe(
      //read data and assign to public variable students
      data => { this.oneExpense = data },
      err => console.error(err),
      () => {
        console.log(this.oneExpense._id);
        this.empId = this.oneExpense.empId;
        this.month = this.oneExpense.month;
        this.year = this.oneExpense.year;
        this.amount = this.oneExpense.amount;
        this.description = this.oneExpense.description;
        this.category = this.oneExpense.category;
        this.notes = this.oneExpense.notes;
        console.log(this.oneExpense.empId);
      }

    );

  }

  //method called OnInit
  getEmployeeList() {
    this._myService2.getEmployees().subscribe(
      //read data and assign to public variable students
      data => { this.empList = data },
      err => console.error(err),
      () => console.log('finished loading employees')
    );
  }

  
  calMonths: Calendar[] = [
    { value: 1, viewValue: 'January' },
    { value: 2, viewValue: 'February' },
    { value: 3, viewValue: 'March' },
    { value: 4, viewValue: 'April' },
    { value: 5, viewValue: 'May' },
    { value: 6, viewValue: 'June' },
    { value: 7, viewValue: 'July' },
    { value: 8, viewValue: 'August' },
    { value: 9, viewValue: 'September' },
    { value: 10, viewValue: 'October' },
    { value: 11, viewValue: 'November' },
    { value: 12, viewValue: 'December' }
  ];

  
  formCategories: string[] = ['Groceries', 'Entertainment', 'Maintenance', 'Auto', 'Other'];

}



