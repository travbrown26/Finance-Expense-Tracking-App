import { Component, OnInit } from '@angular/core';
import { ExpenseSrvc } from '../expenses.service';
import { EmployeeService } from '../employee.service';




@Component({
  selector: 'app-list-expenses',
  templateUrl: './list-expenses.component.html',
  styleUrls: ['./list-expenses.component.css']
})
export class ListExpensesComponent implements OnInit {

  //declare variable to hold response and make it public to be accessible from components.html
  public monthlyexpenses;
  public listEmp;
   

  //initialize the call using StudentService 
  constructor(private _myService: ExpenseSrvc, private _myService2: EmployeeService) { }

  ngOnInit() {
    this.getExpenseList();

    this.getEmployeeList();


  }

  onDelete(expenseId: string) {
    this._myService.deleteExpense(expenseId);
  }

  //method called OnInit
  getExpenseList() {
    this._myService.getExpenses().subscribe(
      //read data and assign to public variable students
      data => { this.monthlyexpenses = data },
      err => console.error(err),
      () => console.log('finished loading expenses')
    );
  }


  getMnth(mn: number) {
    var d = ' ';
    if (mn == 1) { d = 'Jan'; }
    if (mn == 2) { d = 'Feb'; }
    if (mn == 3) { d = 'Mar'; }
    if (mn == 4) { d = 'Apr'; }
    if (mn == 5) { d = 'May'; }
    if (mn == 6) { d = 'Jun'; }
    if (mn == 7) { d = 'Jul'; }
    if (mn == 8) { d = 'Aug'; }
    if (mn == 9) { d = 'Sep'; }
    if (mn == 10) { d = 'Oct'; }
    if (mn == 11) { d = 'Nov'; }
    if (mn == 12) { d = 'Dec'; }
    return d;
  }

  //method called OnInit
  getEmployeeList() {
    this._myService2.getEmployees().subscribe(
      //read data and assign to public variable students
      data => { this.listEmp = data },
      err => console.error(err),
      () => console.log('finished loading employees')
    );
  }

  getEmp(t, eid) {
 var eDetails;

let list = t;
for (let i in list) {
    if (list[i]["_id"] === eid) {
      eDetails = list[i]["firstName"] + ' ' + list[i]["lastName"] + ' (' + list[i]["email"] + ')';
   }
 }
return eDetails;
  }

}
