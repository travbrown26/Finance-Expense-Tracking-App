import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { MatFormFieldModule } from '@angular/material';
import { MatInputModule } from '@angular/material'; 
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { MatButtonModule} from '@angular/material/button';
import { MatExpansionModule} from '@angular/material/expansion';
import { Routes, RouterModule } from '@angular/router';
import { MatMenuModule } from '@angular/material';
import { MatIconModule } from '@angular/material';

import { ExpenseSrvc } from './expenses.service';
import { EmployeeService } from './employee.service';
import { UtilityService } from './utility.service';
import { ReportService } from './report.service';

import { NewEmployeeFormComponent } from './new-employee-form/new-employee-form.component';
import { NavigationMenuComponent } from './navigation-menu/navigation-menu.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { HeaderComponent } from './header/header.component';
import { HomepageComponent } from './homepage/homepage.component';
import { ExpenseReportsComponent } from './expense-reports/expense-reports.component';
import { ExpenseSearchFormComponent } from './expense-search-form/expense-search-form.component';
import { FilteredExpensesComponent } from './filtered-expenses/filtered-expenses.component';
import { ListExpensesComponent } from './list-expenses/list-expenses.component';
import { NewExpenseFormComponent } from './new-expenses-form/new-expenses-form.component';
import { MaterialModule } from './material-module';
import { NewUtilityFormComponent } from './new-utility-form/new-utility-form.component';
import { ListUtilitiesComponent } from './list-utilities/list-utilities.component';
import { NewReportFormComponent } from './new-report-form/new-report-form.component';
import { ListReportsComponent } from './list-reports/list-reports.component';
import { Navigation1MenuComponent} from './navigation1-menu/navigation1-menu.component';
import { Navigation2MenuComponent} from './navigation2-menu/navigation2-menu.component';
import { Navigation3MenuComponent} from './navigation3-menu/navigation3-menu.component';

const appRoutes: Routes = [ {
  path: '',                     //default component to display
   component: HomepageComponent
 },       {
   path: 'addEmployees',         //when employee added 
   component: NewEmployeeFormComponent
 },       {
  path: 'editEmployee/:_id',         //when employee edited 
  component: NewEmployeeFormComponent
},        {
   path: 'listEmployees',       //when employee listed
   component: ListEmployeesComponent
 }, {
  path: 'addExpense',         //when expense added 
  component: NewExpenseFormComponent
}, {
  path: 'editExpense/:_id',       //when expense updated
  component: NewExpenseFormComponent
}, {
  path: 'listExpenses',       //when expense listed
  component: ListExpensesComponent
}, {
  path: 'search',                 //Search Form
  component: ExpenseSearchFormComponent
}, {
  path: 'listFilteredExpenses',                 //List expenses
  component: FilteredExpensesComponent
}, {
  path: 'totalExpenses',                 //Reports Page
  component: ExpenseReportsComponent
}, {
  path: 'reports',                 //Reports Page
  component: ExpenseReportsComponent
},  {
  //Add Utility page route
  path: 'addUtility',
  component: NewUtilityFormComponent
},   {
  //Update Utility page route
  path: 'editUtility/:_id',
  component: NewUtilityFormComponent
},   {
  //List Utilities page route
  path: 'listUtilities',
  component: ListUtilitiesComponent
},  {
  path: 'addReport',
  component: NewReportFormComponent
},  {
  path: 'editReport/:_id',
  component: NewReportFormComponent
},  {path: 'listReports',
  component: ListReportsComponent
},   {
   path: '**',                 //when path cannot be found
   component: NotFoundComponent
 }
];




@NgModule({
  declarations: [
    AppComponent,
    NewEmployeeFormComponent,
    NavigationMenuComponent,
    ListEmployeesComponent,
    NotFoundComponent,
    HeaderComponent,
    HomepageComponent,
    ExpenseReportsComponent,
    ExpenseSearchFormComponent,
    FilteredExpensesComponent,
    ListExpensesComponent,
    NewExpenseFormComponent,
    NewUtilityFormComponent,
    ListUtilitiesComponent,
    NewReportFormComponent,
    ListReportsComponent,
    Navigation1MenuComponent,
    Navigation2MenuComponent,
    Navigation3MenuComponent
    
    
  ],
  
  imports: [
    BrowserModule,
    MatExpansionModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatButtonModule,
    FormsModule,
    MatMenuModule,
    MatIconModule,
    MaterialModule,
    RouterModule.forRoot(appRoutes)
    
  ],
  providers: [EmployeeService,ExpenseSrvc,UtilityService,ReportService],
  bootstrap: [AppComponent]
})
export class AppModule { }
