import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation2-menu',
  templateUrl: './navigation2-menu.component.html',
  styleUrls: ['./navigation2-menu.component.css']
})
export class Navigation2MenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
