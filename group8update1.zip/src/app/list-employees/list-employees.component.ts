import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-list-employees',
  templateUrl: './list-employees.component.html',
  styleUrls: ['./list-employees.component.css']
})
export class ListEmployeesComponent implements OnInit {

  public employees;
  //initialize the call using EmployeeService 
  constructor(private _myService: EmployeeService) { }
  ngOnInit() {
    this.getEmployees();
  }
  //method called OnInit

  onDelete(employeeId: string) {
    this._myService.deleteEmployee(employeeId);
  }

  getEmployees() {
   this._myService.getEmployees().subscribe(
      //read data and assign to public variable employees
      data => { this.employees = data},
      err => console.error(err),
      () => console.log('finished loading')
    );
    
  }
}
