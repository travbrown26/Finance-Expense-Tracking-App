import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//we know that response will be in JSON format
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


const travelDB = "http://localhost:8000/traveldb/";
@Injectable()
export class ReportService {
    constructor(private http:HttpClient) {}
    // Uses http.get() to load data 
    getReport() {
        return this.http.get(travelDB, httpOptions);
    }
    addReport(reportTitle: string, type1: string, type2: string, type3 : string, type4: string, type5: string, type6: string, type7 : string, type8: string, type9: string){ 
        this.http.post('http://localhost:8000/traveldb' , {reportTitle,type1, type2, type3, type4, type5, type6, type7, type8, type9 }) //group decision to change this to a menu (see bottom for subsections)
        .subscribe((responseData) => {
            console.log(responseData);
        }); 
    }
    updateReport(id: string, reportTitle: string, type1: string, type2: string, type3 : string, type4: string, type5: string, type6: string, type7 : string, type8: string, type9: string){
        this.http.put("http://localhost:8000/traveldb/" +id, {reportTitle,type1, type2, type3, type4, type5, type6, type7, type8, type9})
            .subscribe((responseData) => {
                console.log('Updated: ' + reportTitle);
                console.log(responseData);
            });
        }
    deleteReport(id: string) {
        this.http.delete("http://localhost:8000/traveldb/" + id)
        .subscribe((responseData) => {
            console.log(responseData);
            });

        }
          /*  var requestUrl = travelDB + id;
            console.log("Delete request sent: " + requestUrl);
            return this.http.delete(requestUrl);        */
    }


/*
* Sam Box – Landing Page and/or Menu and Travel Expenditures
        Menu should allow you to create a report type
        --level 2 should take user to an option for creating headings for custom reports
        --level 3 should take user to a landing page for the subsections that allows user entry
        --level 4 should take user to submitted report creation 

* Travis Brown - Salaries/Wages (Possibly Benefits)

* Willard Foster - Personal and Business Utility Expenses

* Kelvin Ngige - Reports and Living expenses (Personal home expenses)
*/