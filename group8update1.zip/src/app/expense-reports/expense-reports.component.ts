import { Component, OnInit } from '@angular/core';
import { ExpenseSrvc } from '../expenses.service';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-expense-reports',
  templateUrl: './expense-reports.component.html',
  styleUrls: ['./expense-reports.component.css']
})
export class ExpenseReportsComponent implements OnInit {

  public report1;
  public report2;
  public report3;
  public report4;
  public listEmp;

  public tst;

  constructor(private _myService: ExpenseSrvc, private _myService2: EmployeeService) {this.getReport1(); }

  ngOnInit() {
    this.getEmployeeList();
    
    this.getReport2();
    this.getReport3();
    this.getReport4();

this.wr();
    
  }
  //methods called OnInit
  getReport1() {
    this._myService.getExpensesRpt1().subscribe(
      //read data and assign to public variable students
      data => { this.report1 = data; },
      err => console.error(err),
      () => console.log('finished Report1 ' + this.report1) 
    );
  }

  getReport2() {
    this._myService.getExpensesRpt2().subscribe(
      //read data and assign to public variable students
      data => { this.report2 = data },
      err => console.error(err),
      () => console.log('finished Report2')
    );
  }

  getReport3() {
    this._myService.getExpensesRpt3().subscribe(
      //read data and assign to public variable students
      data => { this.report3 = data },
      err => console.error(err),
      () => console.log('finished Report3')
    );
  }

  getReport4() {
    this._myService.getExpensesRpt4().subscribe(
      //read data and assign to public variable students
      data => { this.report4 = data },
      err => console.error(err),
      () => console.log('finished Report4')
    );
  }

  getMnth(mn: number) {
    var d = ' ';
    if (mn == 1) { d = 'Jan'; }
    if (mn == 2) { d = 'Feb'; }
    if (mn == 3) { d = 'Mar'; }
    if (mn == 4) { d = 'Apr'; }
    if (mn == 5) { d = 'May'; }
    if (mn == 6) { d = 'Jun'; }
    if (mn == 7) { d = 'Jul'; }
    if (mn == 8) { d = 'Aug'; }
    if (mn == 9) { d = 'Sep'; }
    if (mn == 10) { d = 'Oct'; }
    if (mn == 11) { d = 'Nov'; }
    if (mn == 12) { d = 'Dec'; }
    return d;
  }

  //method called OnInit
  getEmployeeList() {
    this._myService2.getEmployees().subscribe(
      //read data and assign to public variable students
      data => { this.listEmp = data },
      err => console.error(err),
      () => console.log('finished loading employees')
    );
  }

  getEmp(t, eid) {
 var eDetails;

let list = t;
for (let i in list) {
    if (list[i]["_id"] === eid) {
      eDetails = list[i]["firstName"] + ' ' + list[i]["lastName"] + ' (' + list[i]["email"] + ')';
   }
 }
return eDetails;
  }


//Charts Test

title = 'Employee Total Expenses';
   type = 'PieChart';
   //data = this.report1.toArray();
   columnNames = ['Employee', 'Amounts'];
   options = {    
   };
   width = 550;
   height = 400;
 
 
   getArr(t) {
    var rptData = '[';
   
   let list = t;
   for (let i in list) {
       
    rptData = rptData + "['" + list[i]["_id"] + "'," + list[i]["totalAmount"] +"]";
      
    }
   this.tst = rptData + '];' ;
   return  rptData + '];' ;
     }
     wr(){
     console.log('1 - '||this.tst);
    }
}
