import { Component, OnInit, Input } from '@angular/core';
import { ReportService } from '../report.service';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-new-report-form',
  templateUrl: './new-report-form.component.html',
  styleUrls: ['./new-report-form.component.css']
})
export class NewReportFormComponent implements OnInit {
  @Input () _id : string
  @Input () reportTitle: string;
  @Input () type1: string;
  @Input () type2: string;
  @Input () type3: string;
  @Input () type4: string;
  @Input () type5: string;
  @Input () type6: string;
  @Input () type7: string;
  @Input () type8: string;
  @Input () type9: string;
  private mode = 'add'; 
  private id: string;
  

  constructor(private reportService: ReportService, private router: Router, public route: ActivatedRoute) { }
  onSubmit (){
    console.log("The data: " + this._id, this.reportTitle + this.type1 +" "+ this.type2 +" "+ this.type3 + " " +  this.type4 + " " + this.type5 + " " + this.type6 +" "+ this.type7 + " " +this.type8 + " "+ this.type9 + " has been added.")
    if(this.mode == 'add')
      this.reportService.addReport(this.reportTitle, this.type1,  this.type2, this.type3, this.type4, this.type5,  this.type6, this.type7, this.type8, this.type9);
    if(this.mode == 'edit')
      this.reportService.updateReport(this._id, this.reportTitle, this.type1,  this.type2, this.type3, this.type4, this.type5,  this.type6, this.type7, this.type8, this.type9);
}
  ngOnInit() {
    this.route.paramMap.subscribe( (paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
      { this.mode='Edit';
        this._id = paramMap.get('_id');}
      else {this.mode = 'Add';
        this.id = null;}
      });
    }
  }