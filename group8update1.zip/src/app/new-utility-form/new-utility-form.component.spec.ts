import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewUtilityFormComponent } from './new-utility-form.component';

describe('NewUtilityFormComponent', () => {
  let component: NewUtilityFormComponent;
  let fixture: ComponentFixture<NewUtilityFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewUtilityFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewUtilityFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
