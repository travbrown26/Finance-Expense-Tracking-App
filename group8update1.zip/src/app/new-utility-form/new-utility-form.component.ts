import { Component, OnInit, Input } from '@angular/core';
import { UtilityService } from '../utility.service';
import { Router } from '@angular/router';
import { ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-new-utility-form',
  templateUrl: './new-utility-form.component.html',
  styleUrls: ['./new-utility-form.component.css']
})
export class NewUtilityFormComponent implements OnInit {
  @Input() firstName: string;
  @Input() lastName: string;
  @Input() email: string;
 // @Input() address: string;
 // @Input() cityName: string;
//  @Input() stateName: string;
 // @Input() zipCode: string;
  @Input() rentAmount: string;
  @Input() cableAmount: string;
  @Input() electricAmount: string;
  @Input() waterAmount: string;
  @Input() gasAmount: string;

  //Default mode
  private mode = 'Add';

  //Utility ID
  private id: string;

  //Initialize the call using UtilityService
  constructor(private _myService: UtilityService, private router: Router, public route: ActivatedRoute) { }
  onSubmit(){
    console.log("You submitted: " + this.firstName + " " + this.lastName + " " + this.email + " "  + this.rentAmount + " " + this.cableAmount + " " + this.electricAmount + " " + this.waterAmount + " " + this.gasAmount);
    if(this.mode == 'Add')
//       this._myService.addUtilities(this.firstName, this.lastName, this.email, this.address, this.cityName, this.stateName, this.zipCode, this.rentAmount, this.cableAmount, this.electricAmount, this.waterAmount, this.gasAmount);
       this._myService.addUtilities(this.firstName, this.lastName, this.email, this.rentAmount, this.cableAmount, this.electricAmount, this.waterAmount, this.gasAmount);
  
       if(this.mode == 'Edit')
 //      this._myService.updateUtility(this.id, this.firstName, this.lastName, this.email, this.address, this.cityName, this.stateName, this.zipCode, this.rentAmount, this.cableAmount, this.electricAmount, this.waterAmount, this.gasAmount);
       this._myService.updateUtility(this.id, this.firstName, this.lastName, this.email, this.rentAmount, this.cableAmount, this.electricAmount, this.waterAmount, this.gasAmount);

       this.router.navigate(['/listUtilities']);
  }

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
        { this.mode = 'Edit';
         this.id = paramMap.get('_id');}
      else { this.mode = 'Add';
        this.id = null; }
    });
  }
}