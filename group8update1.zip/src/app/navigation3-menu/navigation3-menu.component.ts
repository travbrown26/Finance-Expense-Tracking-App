import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigation3-menu',
  templateUrl: './navigation3-menu.component.html',
  styleUrls: ['./navigation3-menu.component.css']
})
export class Navigation3MenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
