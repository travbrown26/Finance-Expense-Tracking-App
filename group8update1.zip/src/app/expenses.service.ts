import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

//we know that response will be in JSON format
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ExpenseSrvc {
  JSON: string;

  constructor(private http: HttpClient) { }

  // Uses http.get() to load data 
  getExpenses() {
    return this.http.get('http://localhost:8000/expenses');
    
  }

  // Uses http.post() to post data 
  addExpenses(empId: string, month: number, year: number, amount: number, description: string, category: string, notes: string) {
    console.log('Inside Expense Recs class  -> addExpenses: ' + empId);
    this.http.post('http://localhost:8000/expenses', {empId, month, year, amount, description, category, notes })
      .subscribe((responseData) => {
        console.log('Inside responseData' + responseData);
      });
    //location.reload();
  }

  updateExpenses(expenseId: string, empId: string, month: number, year: number, amount: number, description: string, category: string, notes: string) {
    //request path http://localhost:8000/students/5xbd456xx 
    //first and last names will be send as HTTP body parameters 
    console.log('Inside updates');
    this.http.put("http://localhost:8000/expenses/"
      + expenseId, {empId, month, year, amount, description, category, notes })
      .subscribe(() => {
        console.log('Updated: ' + expenseId);
      });
    //  location.reload();
  }


  deleteExpense(expenseId: string) {
    this.http.delete("http://localhost:8000/expenses/" + expenseId)
      .subscribe(() => {
        console.log('Deleted: ' + expenseId);
      });
    location.reload();
  }

  getOneExpense(expenseId: string) {
    return this.http.get('http://localhost:8000/expenses/' + expenseId);
    //location.reload(); 
  }

  getByFilter(month: number, year: number, yearOp: string, amount: number, amtOp: string, category: string) {
    console.log('In getByFilter: ' + month);
    return this.http.get('http://localhost:8000/expenses_filtered?year=' + year + '&yearOp=' + yearOp + '&amount=' + amount +
      '&amtOp=' + amtOp + '&month=' + month + '&category=' + category);
    //location.reload(); 
  }

  getExpensesRpt1() {
    return this.http.get('http://localhost:8000/reports/1');

  }
  getExpensesRpt2() {
    return this.http.get('http://localhost:8000/reports/2');

  }
  getExpensesRpt3() {
    return this.http.get('http://localhost:8000/reports/3');

  }
  getExpensesRpt4() {
    return this.http.get('http://localhost:8000/reports/4');

  }
}
