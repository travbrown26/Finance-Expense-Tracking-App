import { Component, OnInit, Input } from '@angular/core';
import { ExpenseSrvc } from '../expenses.service';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';

export interface Calendar {
  value: number;
  viewValue: string;
}
export interface formCategories {
  value: string;
  viewValue: string;
}
export interface opFilters {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-expense-search-form',
  templateUrl: './expense-search-form.component.html',
  styleUrls: ['./expense-search-form.component.css']
})



export class ExpenseSearchFormComponent implements OnInit {
  @Input() month: number;
  @Input() year: number;
  @Input() amount: number;
  @Input() category: string;
  @Input() yearOp: string;
  @Input() amtOp: string;

  constructor(private _myService: ExpenseSrvc, private router: Router, public route: ActivatedRoute) { }

  private mode = 'add'; //default mode
  private id: string; //student ID

  private expTest;


  ngOnInit() {
    

  }

  onSubmit() {
    if (!this.yearOp) { this.yearOp = 'eq'; }
    if (!this.amtOp) { this.amtOp = 'eq'; }

  /*  console.log("You submitted: " + this.year + " y: " + this.yearOp + " " + this.month + " " + this.amount + " " +
      " a: " + this.amtOp + " " + this.category);*/

    this._myService.getByFilter(this.month, this.year, this.yearOp, this.amount, this.amtOp, this.category);

    this.router.navigate(['/listFilteredExpenses'],
      { state: { year: this.year, amount: this.amount, yearOp: this.yearOp, amtOp: this.amtOp, month: this.month, category: this.category } });
  }

  calMonths: Calendar[] = [
    { value: 1, viewValue: 'January' },
    { value: 2, viewValue: 'February' },
    { value: 3, viewValue: 'March' },
    { value: 4, viewValue: 'April' },
    { value: 5, viewValue: 'May' },
    { value: 6, viewValue: 'June' },
    { value: 7, viewValue: 'July' },
    { value: 8, viewValue: 'August' },
    { value: 9, viewValue: 'September' },
    { value: 10, viewValue: 'October' },
    { value: 11, viewValue: 'November' },
    { value: 12, viewValue: 'December' }
  ];
  categories: formCategories[] = [
    { value: 'Groceries', viewValue: 'Groceries' },
    { value: 'Entertainment', viewValue: 'Entertainment' },
    { value: 'Maintenance', viewValue: 'Maintenance' },
    { value: 'Auto', viewValue: 'Auto' },
    { value: 'Other', viewValue: 'Other' },
  ];

  filters: opFilters[] = [
    { value: 'eq', viewValue: ' = ' },
    { value: 'gt', viewValue: ' > ' },
    { value: 'lt', viewValue: ' < ' },
    { value: 'gte', viewValue: ' >= ' },
    { value: 'lte', viewValue: ' <= ' },
  ];

}

