import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpenseSearchFormComponent } from './expense-search-form.component';

describe('ExpenseSearchFormComponent', () => {
  let component: ExpenseSearchFormComponent;
  let fixture: ComponentFixture<ExpenseSearchFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpenseSearchFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpenseSearchFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
