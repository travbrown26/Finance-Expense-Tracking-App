import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
//we know that response will be in JSON format
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
 
@Injectable()
export class EmployeeService {
 
    constructor(private http:HttpClient) {}
 
    // Uses http.get() to load data 
    getEmployees() {
        return this.http.get('http://localhost:8000/employees');
    }
    // Uses http.post() to post data 
addEmployees(firstName: string, lastName: string, email: string, address: string, cityName: string, stateName: string, zipCode: string, positionName: string, salaryAmount: number) {
    this.http.post('http://localhost:8000/employees',{ firstName, lastName, email, address, cityName, stateName, zipCode, positionName, salaryAmount })
  .subscribe((responseData) => {
     console.log(responseData);
   }); 
   location.reload();
}
deleteEmployee(employeeId: string) {
    this.http.delete("http://localhost:8000/employees/" + employeeId)
      .subscribe(() => {
          console.log('Deleted: ' + employeeId);
      });
      location.reload();
  }
  
  updateEmployee(employeeId: string, firstName: string, lastName: string, email: string, address: string, cityName: string, stateName: string, zipCode: string, positionName: string, salaryAmount: number) {
    //request path http://localhost:8000/students/5xbd456xx 
    //first and last names will be send as HTTP body parameters 
        this.http.put("http://localhost:8000/employees/" 
             + employeeId,{ firstName, lastName, email, address, cityName, stateName, zipCode, positionName, salaryAmount })
          .subscribe(() => {
              console.log('Updated: ' + employeeId);
          location.reload();
            });
          
    }
    getOneEmployee(employeeId: string) {
        return this.http.get("http://localhost:8000/employees/" + employeeId);
        location.reload(); 
      }

}



