import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../utility.service';

@Component({
  selector: 'app-list-utilities',
  templateUrl: './list-utilities.component.html',
  styleUrls: ['./list-utilities.component.css']
})
export class ListUtilitiesComponent implements OnInit {

  public utilities;

  //Initialize the call using UtilityService
  constructor(private _myService: UtilityService) { }

  ngOnInit() {
    this.getUtilities();
  }
  //Method called OnInit
  getUtilities() {
    this._myService.getUtilities().subscribe(
      //Read data and assign to public variable utility
      data => { this.utilities = data },
      err => console.error(err),
      () => console.log('finished loading')
    );
  }
  //Method called to delete information or form
  onDelete(utilityId: string) {
    this._myService.deleteUtilities(utilityId);
  }
}