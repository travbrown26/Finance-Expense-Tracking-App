import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UtilityService {

    constructor(private http:HttpClient) {}

    //Uses http.get() to load data
    getUtilities() {
        return this.http.get('http://localhost:8000/utilities');
    }

    //Uses http.post() to post data
    addUtilities(firstName: string, lastName: string, email: string, rentAmount: string, cableAmount: string, electricAmount: string, waterAmount: string, gasAmount: string) {
        this.http.post('http://localhost:8000/utilities', { firstName, lastName, email, rentAmount, cableAmount, electricAmount, waterAmount, gasAmount })
        .subscribe((responseData) => {
            console.log(responseData);
        });
        location.reload();
    }

    //Used to delete data
    deleteUtilities(utilityId: string) {
        this.http.delete("http://localhost:8000/utilities/" + utilityId)
        .subscribe(() => {
            console.log('Deleted: ' + utilityId);
        });
        location.reload();
    }
    
//address: string, cityName: string, stateName: string, zipCode: string,
//address, cityName, stateName, zipCode,
    updateUtility(utilityId: string, firstName: string, lastName: string, email: string,  rentAmount: string, cableAmount: string, electricAmount: string, waterAmount: string, gasAmount: string) {

        //Request path http://localhost:8000/utilities
        //First name, last name, address, city, state, zip code, rent amount, cable amount, electric amount, water amount, and gas amount will be sent as HTTP body parameters
        this.http.put("http://localhost:8000/utilities/" + utilityId, { firstName, lastName, email,  rentAmount, cableAmount, electricAmount, waterAmount, gasAmount })
        .subscribe(() => {
            console.log('Updated: ' + utilityId);
        });
        location.reload();
    }   
  
}
