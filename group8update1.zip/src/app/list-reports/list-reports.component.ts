import { Component, OnInit } from '@angular/core';
import { ReportService } from '../report.service';

@Component({
  selector: 'app-list-reports',
  templateUrl: './list-reports.component.html',
  styleUrls: ['./list-reports.component.css']
})
export class ListReportsComponent implements OnInit {
  public travelDB;
  constructor (private myService: ReportService) {}
  ngOnInit () {
    this.getReport();
  }
  getReport() {
    this.myService.getReport().subscribe(
      data => {this.travelDB = data},
      err => console.error(err),
      () => console.log('finished loading')
    );
  }
  onDelete(reportId: string) {
    this.myService.deleteReport(reportId);
  }
}
