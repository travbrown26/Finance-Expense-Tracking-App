const mongoose = require ('mongoose');

const reportSchema = new mongoose.Schema({
    reportTitle: {type: String, required: true},
    type1: {type: String, required: true},
    type2: {type: String, required: true},
    type3: { type: String, required: true},
    type4: {type: String, required: true},
    type5: {type: String, required: true},
    type6: {type: String, required: true},
    type7: { type: String, required: true},
    type8: {type: String, required: true},
    type9: {type: String, required: true}
});

//use the blueprint to create the model
//parameters: (model name, schema, to use, collection name)
//module.exports is used to allow external access to the model
module.exports = mongoose.model ('report', reportSchema, 'travelDB');