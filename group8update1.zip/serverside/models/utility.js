const mongoose = require('mongoose');

//Defines the Utility schema
const utilitySchema = new mongoose.Schema({
    firstName: { type: String, required: true},
    lastName: { type: String, required: true},
    email: { type: String, required: true},
 /*   address: { type: String, required: true},
    cityName: { type: String, required: true},
    stateName: { type: String, required: true},
    zipCode: { type: String, required: true},*/
    rentAmount: { type: String, required: true},
    cableAmount: { type: String, required: true},
    electricAmount: { type: String, required: true},
    waterAmount: { type: String, required: true},
    gasAmount: { type: String, required: true}
});

//Used to allow external access to the model
module.exports = mongoose.model('Utility', utilitySchema, 'Utility');