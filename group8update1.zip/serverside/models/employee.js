const mongoose = require('mongoose');

//define a schema/ blueprint NOTE: id is not a part of the schema 
  const employeeSchema = new mongoose.Schema({
    firstName:  { type: String, required: true},
    lastName:  { type: String, required: true},
    email: { type: String, required: true},
    address: { type: String, required: true},
    cityName: { type: String, required: true},
    stateName: { type: String, required: true},
    zipCode: { type: String, required: true},
    positionName: { type: String, required: true},
    salaryAmount: { type: Number, required: true}
  });

//use the blueprint to create the model 
// Parameters: (model_name, schema_to_use, collection_name)
//module.exports is used to allow external access to the model  
module.exports = mongoose.model('Employee', employeeSchema,'Employees');
//note capital S in the collection name
