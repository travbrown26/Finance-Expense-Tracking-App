const mongoose = require('mongoose');

const express = require('express');
const app = express();

const bodyParser  = require('body-parser');

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))
// parse application/json
app.use(bodyParser.json())

const Expense = require('./models/expense')
const Employee = require('./models/employee')
const Utility = require('./models/utility')
const travelDB = require('./models/travelReport')

// Connect to MongoDB Atlas server and display the status 
mongoose.connect('mongodb+srv://kngige:K$ugr0upB@finance-expense-tracking-yf8rp.mongodb.net/test?retryWrites=true', { useNewUrlParser: true })
  .then(() => { console.log("Connected"); })
  .catch(() => { console.log("error connecting"); });

// use the following code on any request that matches the specified mount path
app.use((req, res, next) => {
   console.log('This line is always called');
   res.setHeader('Access-Control-Allow-Origin', '*'); //can connect from any host
   res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS, DELETE'); //allowable methods
   res.setHeader('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept');
   next();
});

//Employees
app.get('/employees', (req, res, next) => {
  //call mongoose method find (MongoDB Atlas Employees collection())
  Employee.find() 
    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
    console.log('Error: ${err}');
    res.status(500).json(err);
  });
//Get one expense - Filter ny the ID passed

app.get("/employees/:id", (req, res, next) => {

  Employee.findOne({
 
  _id: req.params.id
 
  }).then(data => res.status(200).json(data))
 
  //if error, send internal server error
 
  .catch(err => {
 
  console.log('Error: ${err}');
 
  res.status(500).json(err);
 
  });
 
 });



// serve incoming post requests to /employees
app.post('/employees', (req, res, next) => {
    // create a new employee variable and save request’s fields 
  const employee = new Employee({firstName: req.body.firstName,lastName: req.body.lastName,email: req.body.email,address: req.body.address,cityName: req.body.cityName,stateName: req.body.stateName,zipCode: req.body.zipCode,positionName: req.body.positionName,salaryAmount: req.body.salaryAmount,
  });
  //send the document to the database 
  employee.save()
    //in case of success
    .then(() => { console.log('Success');})
    //if error
    .catch(err => {console.log('Error:' + err);});

  });
  


//:id is a dynamic parameter that will be extracted from the URL
app.delete("/employees/:id", (req, res, next) => {
  Employee.deleteOne({ _id: req.params.id }).then(result => {
    console.log(result);
    res.status(200).json("Deleted!");
  });
});

// serve incoming put requests to /students
  app.put('/employees/:id', (req, res, next) => {
    console.log("id: " + req.params.id)
    // check that the parameter id is valid 
    if (mongoose.Types.ObjectId.isValid(req.params.id)) {
      //find a document and set new first and last names
      Employee.findOneAndUpdate({_id: req.params.id},
        {$set:{firstName: req.body.firstName,lastName: req.body.lastName, email: req.body.email, address: req.body.address, cityName: req.body.cityName,stateName: req.body.stateName,zipCode: req.body.zipCode,positionName: req.body.positionName,salaryAmount: req.body.salaryAmount}},{new:true}) 
       .then((employee) => {
          if (employee) { //what was updated
            console.log(employee);
          } else {
            console.log("no data exist for this id");
          }
       })
      .catch((err) => {
        console.log(err);
       });
   } else {
     console.log("please provide correct id");
   }
    
  });

});

// Expenses
//Insert new expenses
app.post('/expenses', (req, res, next) => {

  const expenserec = new Expense({
    empId: req.body.empId,
    month: req.body.month,
    year: req.body.year,
    amount: req.body.amount,
    description: req.body.description,
    category: req.body.category,
    notes: req.body.notes
  });

    //send the document to the database 
  expenserec.save()
    //in case of success
    .then(() => {
      console.log('New Record Inserted ');
    })
    //if error
    .catch(err => {
      console.log('empId: ' + empId);
      console.log('Insertex Error: ' + err);
    });
});

//Get all the expenses
app.get('/expenses', (req, res, next) => {
  Expense.find().sort({
      year: -1,
      month: -1
    })
    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});

//Get one expense - Filter ny the ID passed
app.get("/expenses/:id", (req, res, next) => {
    Expense.findOne({
      _id: req.params.id
    }).then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});

// Get list of expenses - Filter by the conditions passed
app.get('/expenses_filtered', (req, res, next) => {
  console.log('Year: ' + req.query.year);
  console.log('Year Filter: ' + req.query.yearOp);
  console.log('Amt: ' + req.query.amount);
  console.log('Amt Filter: ' + req.query.amtOp);
  console.log('Month: ' + req.query.month);
  console.log('Category: ' + req.query.category);

  //Build our query parameter and put it in the dbQuery variable
  var yFltr = {};
  var aFltr = {};
  var dbQuery = {};

  //Year and its operator
  if (req.query.year && req.query.year != 'undefined' && req.query.yearOp != 'eq') {

    switch (req.query.yearOp) {
      case 'gt':
        yFltr.$gt = parseInt(req.query.year);
        dbQuery.year = yFltr;
        break;
      case 'gte':
        yFltr.$gte = parseInt(req.query.year);
        dbQuery.year = yFltr;
        break;
      case 'lt':
        yFltr.$lt = parseInt(req.query.year);
        dbQuery.year = yFltr;
        break;
      case 'lte':
        yFltr.$lte = parseInt(req.query.year);
        dbQuery.year = yFltr;
        break;
      default:
        // Do Nothing
    }
  } else if (req.query.year && req.query.year != 'undefined' && req.query.yearOp == 'eq') {
    dbQuery.year = parseInt(req.query.year);
  }

  //Amount and its operator
  if (req.query.amount && req.query.amount != 'undefined' && req.query.amtOp != 'eq') {

    switch (req.query.amtOp) {
      case 'gt':
        aFltr.$gt = parseFloat(req.query.amount);
        dbQuery.amount = aFltr;
        break;
      case 'gte':
        aFltr.$gte = parseFloat(req.query.amount);
        dbQuery.amount = aFltr;
        break;
      case 'lt':
        aFltr.$lt = parseFloat(req.query.amount);
        dbQuery.amount = aFltr;
        break;
      case 'lte':
        aFltr.$lte = parseFloat(req.query.amount);
        dbQuery.amount = aFltr;
        break;
      default:
        // Do Nothing
    }
  } else if (req.query.amount && req.query.amount != 'undefined' && req.query.amtOp == 'eq') {
    dbQuery.amount = parseInt(req.query.amount);
  }

  //Month
  if (req.query.month && req.query.month != 'undefined') {
    dbQuery.month = parseInt(req.query.month);
  }

  //Category
  if (req.query.category && req.query.category != 'undefined') {
    dbQuery.category = req.query.category;
  }

  // Rin Find() with the filters
  Expense.find(dbQuery).sort({
      year: -1,
      month: -1
    })
    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});

//Delete record
app.delete("/expenses/:id", (req, res, next) => {
  Expense.deleteOne({
    _id: req.params.id
  }).then(result => {
    console.log(result);
    res.status(200).json("Deleted!");
  });
});

// Update record
app.put('/expenses/:id', (req, res, next) => {
  // check that the parameter id is valid 
  if (mongoose.Types.ObjectId.isValid(req.params.id)) {
    
    Expense.findOneAndUpdate({
        _id: req.params.id
      }, {
        $set: {
          empId: req.body.empId,
          month: req.body.month,
          year: req.body.year,
          amount: req.body.amount,
          description: req.body.description,
          category: req.body.category,
          notes: req.body.notes
        }
      }, {
        new: true
      }).then((expense) => {
        if (expense) { //what was updated
          console.log('Update Successful');
        } else {
          console.log("no data exist for this id");
        }
      })
      .catch((err) => {
        console.log(err);
      });
  } else {
    console.log("please provide correct id");
  }

});

app.get('/reports/1', (req, res, next) => {
  //call mongoose method find (MongoDB db.Students.find())
  console.log('Report 1');

  Expense.aggregate(
      [{
        $group: {
          _id: '$empId',
          totalAmount: {
            $sum: '$amount'
          }

        }
      }]
    ).sort({
      _id: -1
    })

    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});


app.get('/reports/2', (req, res, next) => {
  //call mongoose method find (MongoDB db.Students.find())
  console.log('Report 2');

  Expense.aggregate(
      [{
        $group: {
          _id: {
            'year': '$year',
            'month': '$month'
          },
          totalAmount: {
            $sum: '$amount'
          }

        }
      }]
    ).sort({
      "_id.year": -1,
      "_id.month": 1
    })

    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});

app.get('/reports/3', (req, res, next) => {
  //call mongoose method find (MongoDB db.Students.find())
  console.log('Report 3');

  Expense.aggregate(
      [{
        $group: {
          _id: {
            'year': '$year',
            'category': '$category'
          },
          totalAmount: {
            $sum: '$amount'
          }

        }
      }]
    ).sort({
      "_id.year": -1,
      "_id.category": 1
    })

    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});

app.get('/reports/4', (req, res, next) => {
  //call mongoose method find (MongoDB db.Students.find())
  Expense.find().sort({
      amount: -1
    }).limit(5)
    //if data is returned, send data as a response 
    .then(data => res.status(200).json(data))
    //if error, send internal server error
    .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
    });
});

// Utilities
app.get('/utilities', (req, res, next) => {

  Utility.find()
  .then(data => res.status(200).json(data))
  .catch(err => {
      console.log('Error: ${err}');
      res.status(500).json(err);
  });
});

//Serve Incoming post requests to /utilities
app.post('/utilities', (req, res, next) => {
  //Create a new form for utilities and saves the request fields
  const utility = new Utility({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      email: req.body.email,
    /*  address: req.body.address,
      cityName: req.body.cityName,
      stateName: req.body.stateName,
      zipCode: req.body.zipCode,*/
      rentAmount: req.body.rentAmount,
      cableAmount: req.body.cableAmount,
      electricAmount: req.body.electricAmount,
      waterAmount: req.body.waterAmount,
      gasAmount: req.body.gasAmount
  });

  //Sends information to the database
  utility.save()

  //If information submits successfully
  .then(() => { console.log('Success');})

  //If there is an error in information
  .catch(err => {console.log('Error:' + err);});    
});

//_id: is a dynamic parameter that will be extracted from the URL
app.delete("/utilities/:id", (req, res, next) => {
  Utility.deleteOne({ _id: req.params.id }).then(result => {
      console.log(result);
      res.status(200).json("Deleted!");
  });
});

//Serve Incoming put requests to /utilities
app.put('/utilities/:id', (req, res, next) => {
  console.log("id: " + req.params.id)
  //Check thast the parameter id is valid
  if (mongoose.Types.ObjectId.isValid(req.params.id)) {
      //Find a document and set new first and last name
      //Find document and set new email, address, city, state, zip code
      //Find document and set new rent, cable, electric, water, and gas amount
      Utility.findOneAndUpdate({_id: req.params.id},
          {$set:{firstName : req.body.firstName,
           lastName : req.body.lastName,
           email : req.body.email,
          /* address : req.body.address,
           cityName : req.body.cityName,
           stateName : req.body.stateName,
           zipCode : req.body.zipCode,*/
           rentAmount : req.body.rentAmount,
           cableAmount : req.body.cableAmount,
           electricAmount : req.body.electricAmount,
           waterAmount : req.body.waterAmount,
           gasAmount : req.body.gasAmount}},{new:true})
          .then((utility) => {
              //Shows what is updated on the console
              if (utility) {
                  console.log(utility);
              } else {
                  console.log("no data exist for this id");
              }
          })
          .catch((err) => {
              console.log(err);
          });
  } else {
      console.log("please provide correct id");
  }
});

//TravelReport
app.get('/travelDB', (req, res, next) => {     
  travelDB.find() 
  .then(data => res.status(200).json (data))
  .catch(err => {
    console.log('Error: ${err}');
    res.status(500).json(err);
  });  
});

app.post('/travelDB', (req, res, next) => {
  const report = new travelDB ({
    reportTitle: req.body.reportTitle,
    type1: req.body.type1,
    type2: req.body.type2,
    type3: req.body.type3,
    type4: req.body.type4,
    type5: req.body.type5,
    type6: req.body.type6,
    type7: req.body.type7,
    type8: req.body.type8,
    type9: req.body.type9
  });
  report.save()
  .then (() => { console.log('Sucess');})
  .catch(err => {console.log('Error:' + err);});
}); 

app.delete("/travelDB/:id", (req, res, next) => {
  travelDB.deleteOne({ _id: req.params.id }).then(result => {
    console.log(result);
    res.status(200).json("Deleted!");
  });
});

app.put('/travelDB/:id', (req, res, next) => {
console.log("_id: " + req.params._id)
if (mongoose.Types.ObjectId.isValid(req.params.id)) {
  travelDB.findOneAndUpdate({_id: req.params.id},
    {$set:{reportTitle: req.body.reportTitle, type1: req.body.type1, type2: req.body.type2, type3: req.body.type3, type4: req.body.type4, type5: req.body.type5, type6: req.body.type6, type7: req.body.type7, type8: req.body.type8, type9: req.body.type9}},{new:true}) 
   .then((report) => {
      if (report) { //what was updated
        console.log(report);
      } else {
        console.log("no data exist for this id");
      }
   })
  .catch((err) => {
    console.log(err);
   });
} else {
 console.log("please provide correct id");
}  
});  

//to use this middleware in other parts of the application
module.exports=app;

